/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ComponenteVisual;

/**
 *
 * @author Caballero Silva Dalia Montserrat y Suyay Fernanda Crespo Castañón
 */
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.font.TextAttribute;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Traductor extends JPanel implements Serializable {

    private static final Color AZUL = new Color(30, 144, 255);
    private static final Color BLANCO = new Color(255, 255, 255);

    private JTextArea textoOriginal;
    private JTextArea textoTraducido;
    private JComboBox<String> idiomaOrigen;
    private JComboBox<String> idiomaDestino;
    private JButton botonTraducir;
    private JLabel estado;
    private JButton botonPersonalizar;

    private final String[] codigosIdioma = {"es", "en", "fr", "de", "it", "pt"};
    private final String[] nombresIdioma = {"Español", "Inglés", "Francés", "Alemán", "Italiano", "Portugués"};

    private static final long serialVersionUID = 1L;

    private Font fuenteTexto = new Font("Comic Sans MS", Font.PLAIN, 14);
    private Color colorFondo = BLANCO;

    public Traductor() {
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        setBackground(colorFondo);
        setPreferredSize(new Dimension(700, 400));

        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        panelSuperior.setBackground(colorFondo);

        idiomaOrigen = new JComboBox<>(nombresIdioma);
        idiomaDestino = new JComboBox<>(nombresIdioma);
        idiomaDestino.setSelectedIndex(1);

        JLabel etiquetaDe = new JLabel("De:");
        JLabel etiquetaA = new JLabel("A:");

        JButton botonIntercambiar = new JButton("⇄");
        botonIntercambiar.addActionListener((ActionEvent e) -> {
            int origen = idiomaOrigen.getSelectedIndex();
            int destino = idiomaDestino.getSelectedIndex();
            idiomaOrigen.setSelectedIndex(destino);
            idiomaDestino.setSelectedIndex(origen);
        });

        panelSuperior.add(etiquetaDe);
        panelSuperior.add(idiomaOrigen);
        panelSuperior.add(botonIntercambiar);
        panelSuperior.add(etiquetaA);
        panelSuperior.add(idiomaDestino);

        JPanel panelCentral = new JPanel(new GridLayout(1, 2, 10, 0));
        panelCentral.setBackground(colorFondo);

        textoOriginal = new JTextArea();
        textoOriginal.setLineWrap(true);
        textoOriginal.setWrapStyleWord(true);
        textoOriginal.setFont(fuenteTexto);

        textoTraducido = new JTextArea();
        textoTraducido.setLineWrap(true);
        textoTraducido.setWrapStyleWord(true);
        textoTraducido.setEditable(false);
        textoTraducido.setFont(fuenteTexto);

        JScrollPane scrollOriginal = new JScrollPane(textoOriginal);
        scrollOriginal.setBorder(BorderFactory.createTitledBorder("Texto original"));

        JScrollPane scrollTraducido = new JScrollPane(textoTraducido);
        scrollTraducido.setBorder(BorderFactory.createTitledBorder("Traducción"));

        panelCentral.add(scrollOriginal);
        panelCentral.add(scrollTraducido);

        JPanel panelInferior = new JPanel(new BorderLayout(0, 5));
        panelInferior.setBackground(colorFondo);

        botonTraducir = new JButton("Traducir");
        botonTraducir.setBackground(AZUL);
        botonTraducir.setForeground(BLANCO);
        botonTraducir.addActionListener((ActionEvent e) -> traducir());

        estado = new JLabel("Listo");

        // Botón de personalización
        botonPersonalizar = new JButton("Personalizar");
        botonPersonalizar.setBackground(AZUL);
        botonPersonalizar.setForeground(BLANCO);
        botonPersonalizar.addActionListener((ActionEvent e) -> mostrarOpcionesPersonalizacion());

        panelInferior.add(botonTraducir, BorderLayout.CENTER);
        panelInferior.add(estado, BorderLayout.SOUTH);
        panelInferior.add(botonPersonalizar, BorderLayout.NORTH);

        add(panelSuperior, BorderLayout.NORTH);
        add(panelCentral, BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);
    }

    private void traducir() {
        String texto = textoOriginal.getText().trim();
        if (texto.isEmpty()) {
            estado.setText("Por favor, ingresa texto para traducir");
            return;
        }

        String origen = codigosIdioma[idiomaOrigen.getSelectedIndex()];
        String destino = codigosIdioma[idiomaDestino.getSelectedIndex()];

        estado.setText("Traduciendo...");
        botonTraducir.setEnabled(false);

        SwingWorker<String, Void> worker = new SwingWorker<>() {
            @Override
            protected String doInBackground() {
                return traducirConMyMemory(texto, origen, destino);
            }

            @Override
            protected void done() {
                try {
                    String traduccion = get();
                    textoTraducido.setText(traduccion);
                    estado.setText(traduccion.startsWith("Error") ? "Error al traducir" : "Traducción completada");
                } catch (Exception e) {
                    textoTraducido.setText("Error: " + e.getMessage());
                    estado.setText("Error al traducir");
                } finally {
                    botonTraducir.setEnabled(true);
                }
            }
        };
        worker.execute();
    }

    private String traducirConMyMemory(String texto, String origen, String destino) {
        try {
            String q = URLEncoder.encode(texto, StandardCharsets.UTF_8);
            String urlStr = "https://api.mymemory.translated.net/get?q=" + q + "&langpair=" + origen + "|" + destino;
            URL url = new URL(urlStr);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();

            JSONParser parser = new JSONParser();
            JSONObject json = (JSONObject) parser.parse(response.toString());
            JSONObject data = (JSONObject) json.get("responseData");
            return (String) data.get("translatedText");

        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    private void mostrarOpcionesPersonalizacion() {
        // Panel de personalización
        JPanel panelPersonalizacion = new JPanel();
        panelPersonalizacion.setLayout(new GridLayout(0, 1, 10, 10));

        // Obtener todas las fuentes disponibles
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        String[] fuentesDisponibles = ge.getAvailableFontFamilyNames();
        JComboBox<String> fuentesCombo = new JComboBox<>(fuentesDisponibles);

        // Colores de la paleta de NetBeans
        String[] coloresDisponibles = {"Blanco", "Azul", "Rosa", "Verde", "Amarillo"};
        JComboBox<String> coloresCombo = new JComboBox<>(coloresDisponibles);

        JButton aplicarButton = new JButton("Aplicar");
        aplicarButton.setBackground(AZUL);
        aplicarButton.setForeground(BLANCO);
        aplicarButton.addActionListener((ActionEvent e) -> {
            // Cambiar fuente
            String fuenteSeleccionada = (String) fuentesCombo.getSelectedItem();
            fuenteTexto = new Font(fuenteSeleccionada, Font.PLAIN, 14);

            // Cambiar color de fondo (solo en las áreas deseadas)
            String colorSeleccionado = (String) coloresCombo.getSelectedItem();
            switch (colorSeleccionado) {
                case "Azul":
                    colorFondo = AZUL;
                    break;
                case "Rosa":
                    colorFondo = new Color(255, 182, 193); // Rosa pastel
                    break;
                case "Verde":
                    colorFondo = new Color(144, 238, 144); // Verde claro
                    break;
                case "Amarillo":
                    colorFondo = new Color(255, 255, 102); // Amarillo pastel
                    break;
                default:
                    colorFondo = BLANCO;
                    break;
            }

            // Aplicar cambios en las áreas de texto y paneles
            setBackground(colorFondo);
            textoOriginal.setFont(fuenteTexto);
            textoTraducido.setFont(fuenteTexto);
            revalidate();
            repaint();
        });

        panelPersonalizacion.add(new JLabel("Seleccionar fuente:"));
        panelPersonalizacion.add(fuentesCombo);
        panelPersonalizacion.add(new JLabel("Seleccionar color de fondo:"));
        panelPersonalizacion.add(coloresCombo);
        panelPersonalizacion.add(aplicarButton);

        // Mostrar el panel
        JOptionPane.showMessageDialog(this, panelPersonalizacion, "Personalizar", JOptionPane.PLAIN_MESSAGE);
    }
}



